import React from 'react';

class CalculateButton extends React.Component{
    render(){
        return(
            <button>Calculate!</button>
        )
    }
}

export default CalculateButton;
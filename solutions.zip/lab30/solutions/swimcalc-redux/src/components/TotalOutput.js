import React from 'react';

function TotalOutput(props) {

    return (
        <div>Total Km: {props.total}</div>
    );

}

export default TotalOutput;
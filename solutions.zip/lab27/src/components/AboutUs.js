import React from 'react';

class AboutUs extends React.Component {
    render(){
        return (<h1>About Us</h1>);
    }
}

export default AboutUs;
const questions = [{
    "question": "What is the best?",
    "choices": [{"value": "Tacos", "label": "Tacos"}, {"value": "Pizza", "label": "Pizza"}, {
        "value": "Cheese",
        "label": "Cheese"
    }],
    "correctAnswer": "Pizza"
}, {
    "question": "What's your favorite color?:",
    "choices": [{"value": "Orange", "label": "Orange"}, {"value": "Blue", "label": "Blue"}],
    "correctAnswer": "Blue"
}];
export default questions;

import React from 'react';

function CalculateButton() {

    return (
        <button>Calculate!</button>
    );
}
  
export default CalculateButton;